// Tests de fumée — AUCUNE écriture en base, aucune inscription, aucune clé admin testée.
// Usage : BASE_URL=… ADMIN_URL=… SUPABASE_URL=https://xxxx.supabase.co SUPABASE_ANON_KEY=… node tests/smoke.mjs
const { BASE_URL, ADMIN_URL, SUPABASE_URL, SUPABASE_ANON_KEY } = process.env;
let fails = 0;
const ok = (n, c, d = "") => { console.log((c ? "OK    " : "ÉCHEC ") + n + (c ? "" : " — " + d)); if (!c) fails++; };

async function api(body) {
  const r = await fetch(`${SUPABASE_URL}/functions/v1/api`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` },
    body: JSON.stringify(body),
  });
  return { status: r.status, json: await r.json().catch(() => ({})) };
}

if (BASE_URL) {
  const r = await fetch(BASE_URL); const t = await r.text();
  ok("accueil 200", r.status === 200, r.status);
  ok("mention non-affiliation", t.includes("non affilié à l'OBC ni à la DECC"));
  ok("contacts publics", t.includes("675444463") && t.includes("693132834"));
  ok("poids page < 150 Ko", Buffer.byteLength(t) < 150 * 1024, Buffer.byteLength(t) + " octets");
}
if (ADMIN_URL) {
  const r = await fetch(ADMIN_URL); const t = await r.text();
  ok("admin 200", r.status === 200, r.status);
  ok("admin noindex", /noindex/i.test(t));
}
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  const p = await api({ action: "prices" });
  ok("prix publics renvoyés", p.status === 200 && !p.json.error, JSON.stringify(p.json).slice(0, 80));
  const bad = await api({ action: "xyz" });
  ok("action inconnue refusée", bad.status === 400);
  const l = await api({ action: "login", phone: "600000000", pin: "135790" });
  ok("connexion erronée : aucun jeton", !l.json.token);
  const g = await fetch(`${SUPABASE_URL}/functions/v1/go`, { redirect: "manual" });
  ok("lien parrainage redirige (302)", g.status === 302, g.status);
}
console.log(fails ? `\n${fails} échec(s) — NE PAS mettre en production.` : "\nTous les contrôles passent.");
process.exit(fails ? 1 : 0);
