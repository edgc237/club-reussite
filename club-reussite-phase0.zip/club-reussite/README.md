# Club Réussite EDGC237 — dépôt de référence

Club indépendant, non affilié à l'OBC ni à la DECC.

## Contenu
- `supabase/functions/` : les 3 fonctions en production (api v5, admin v2, go v2), copie exacte au 23/10/2026.
- `supabase/migrations/` : à remplir avec `supabase db pull` (14 migrations déjà appliquées, de `moteur_codes_v0_1` à `controle_auto_parrainage_confirmation_2026_10_22`).
- `app/` et `admin/` : `index.html` + `vercel.json` de chaque site, à déposer depuis Vercel (onglet Source du déploiement de production).
- `tests/smoke.mjs` : tests de fumée, sans aucune écriture en base.
- `docs/RETOUR_ARRIERE.md`, `docs/SAUVEGARDE.md`, `scripts/backup.sh`.

## Règles
1. Aucun secret dans ce dépôt (clé admin, service role, mot de passe base).
2. `index.html` et `vercel.json` à la racine du dossier déployé, sans préfixe `src/`.
3. Chaque changement : branche, aperçu Vercel, `npm run smoke` sur l'aperçu, puis fusion dans `main`.
4. Toute modification de base : une migration versionnée, essayée d'abord dans BEGIN … ROLLBACK, avec sa migration inverse écrite avant.
