# Retour arrière — 1 page

Quand ? Après une mise en production : inscription, connexion ou retrait en échec, page blanche, erreur 404.

## A. Site (appli membre ou administration) — 2 minutes
Constat du 23/10/2026 : l'adresse officielle pointe vers un déploiement que Vercel étiquette « Preview » (pas « Production »). Le bouton Instant Rollback / Promote peut donc ramener une VIEILLE version. Ne pas l'utiliser sans vérifier.
1. Vercel → projet → Deployments.
2. Repérer l'avant-dernier déploiement qui fonctionnait (comparer date et aperçu).
3. Ouvrir ce déploiement → Domains / Assign Domain → rattacher `club-reussite.vercel.app` (ou `club-reussite-admin.vercel.app`) à lui.
4. Ouvrir l'adresse officielle sur téléphone : accueil, « Se connecter ».
Déploiements actuels : appli = dpl_FM8ysw12St5dMnfGjSEEQQkBpjUS ; admin = dpl_DL68ofGtLpbKBNr5xrtoofBoGdGF ; précédent appli = dpl_BLmbCxfky7ixtMuJvxxBKt16qK3t.

## B. Fonction Supabase (api, admin, go) — 5 minutes
1. Référence : `supabase/functions/<nom>/index.ts` du dernier commit sain.
2. Redéployer : `supabase functions deploy <nom>`.
3. Contrôler : `npm run smoke`.

## C. Base de données — le plus délicat
1. Ne jamais supprimer de colonne ou de table directement : ajouter d'abord, retirer plus tard.
2. Chaque migration a sa migration inverse, écrite avant l'application.
3. Dernier recours : restaurer la dernière sauvegarde (docs/SAUVEGARDE.md) dans le projet de test, vérifier, puis rejouer.

## D. Clé administrateur
Si elle a pu être exposée : la changer, se reconnecter, relire le journal d'administration.

## Après
Noter date, cause, version restaurée. Corriger sur une branche, jamais directement en production.
