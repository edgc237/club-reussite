# Sauvegarde et restauration — plan Supabase Free

À ma connaissance, le plan Free ne fournit pas de sauvegardes téléchargeables : à confirmer dans Supabase → Database → Backups. Les projets Free inactifs sont mis en pause : ouvrir l'appli au moins une fois par semaine.

## Rythme
- Avant chaque migration en production.
- Au minimum une fois par semaine : `./scripts/backup.sh`.
- Copier le résultat dans un Drive privé (il contient des numéros de téléphone : jamais dans Git).

## Test de restauration (une fois, puis chaque trimestre)
1. Créer un projet Supabase gratuit `club-reussite-test`.
2. `supabase link --project-ref <ref du projet de test>`.
3. Rejouer `schema.sql` puis `data.sql` avec psql.
4. Vérifier : nombre de membres, d'adhésions, paramètres.
5. Noter date et durée.

## Si le plan passe à Pro
Activer les sauvegardes automatiques et la restauration à un instant donné ; garder ce script en complément.
