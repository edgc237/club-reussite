#!/usr/bin/env bash
# Sauvegarde manuelle (plan Free). Prérequis : Supabase CLI connecté et projet lié (supabase link).
set -euo pipefail
D="backups/$(date +%Y-%m-%d_%H%M)"; mkdir -p "$D"
supabase db dump -f "$D/schema.sql"
supabase db dump --data-only --use-copy -f "$D/data.sql"
gzip "$D"/*.sql
echo "Sauvegarde dans $D — à copier dans un Drive privé. Jamais dans Git."
