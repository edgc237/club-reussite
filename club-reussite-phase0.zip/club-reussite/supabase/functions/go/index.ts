import { createClient } from "npm:@supabase/supabase-js@2";

// Lien tracé public : enregistre un clic puis redirige vers la boutique (destination fixe).
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const SHOP = "https://edgc237.vercel.app/";

async function sha(s: string) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}

// IP fournie par l'infrastructure (non falsifiable) ; jamais le premier maillon de x-forwarded-for.
const clientIp = (r: Request) =>
  r.headers.get("cf-connecting-ip") ?? r.headers.get("x-real-ip") ??
  r.headers.get("x-forwarded-for")?.split(",").pop()?.trim() ?? "?";

Deno.serve(async (req) => {
  const code = (new URL(req.url).searchParams.get("c") ?? "").toUpperCase();
  const dest = new URL(SHOP);
  if (/^[A-Z0-9]{8}$/.test(code)) {
    try {
      const day = new Date().toISOString().slice(0, 10);
      await db.rpc("log_click", { p_code: code, p_ip: (await sha(clientIp(req) + day + code)).slice(0, 32) });
    } catch { /* ne jamais bloquer la redirection */ }
    dest.searchParams.set("ref", code);
  }
  dest.searchParams.set("utm_source", "club");
  dest.searchParams.set("utm_medium", "parrainage");
  return new Response(null, { status: 302, headers: { Location: dest.toString() } });
});
