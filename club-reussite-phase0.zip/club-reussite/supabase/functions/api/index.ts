import { createClient } from "npm:@supabase/supabase-js@2";

const KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(Deno.env.get("SUPABASE_URL")!, KEY);
const H = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Content-Type": "application/json",
};
const out = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: H });

// Empreinte non réversible de la connexion (jamais l'IP en clair)
const enc = new TextEncoder();
async function ipHash(req: Request): Promise<string> {
  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-real-ip") ??
    req.headers.get("x-forwarded-for")?.split(",").pop()?.trim() ?? "?";
  const k = await crypto.subtle.importKey("raw", enc.encode(KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const s = await crypto.subtle.sign("HMAC", k, enc.encode(ip));
  return [...new Uint8Array(s)].map((x) => x.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

type Route = (b: any, ip: string) => [string, Record<string, unknown>];
const routes: Record<string, Route> = {
  register: (b, ip) => ["register_member", { p_phone: b.phone, p_name: b.name, p_kind: b.kind, p_level: b.level, p_minor: !!b.minor, p_consent: !!b.consent, p_ref: b.ref ?? null, p_pin: b.pin, p_ip: ip }],
  login: (b) => ["login_member", { p_phone: b.phone, p_pin: b.pin }],
  recover: (b) => ["recover_member", { p_phone: b.phone, p_code: b.code, p_new_pin: b.pin }],
  me: (b) => ["me_member", { p_token: b.token }],
  logout: (b) => ["logout_member", { p_token: b.token }],
  prices: () => ["public_prices", {}],
  quote: (b) => ["my_quote", { p_token: b.token, p_level: b.level }],
  dashboard: (b) => ["my_dashboard", { p_token: b.token }],
  withdraw: (b) => ["request_withdrawal", { p_token: b.token, p_amount: parseInt(b.amount, 10) || 0, p_provider: b.provider, p_phone: b.phone, p_pin: b.pin ?? null }],
};

// Limites larges (plusieurs élèves peuvent partager une même connexion mobile)
const LIMITS: Record<string, (ip: string) => [string, number, number][]> = {
  register: (ip) => [["reg:" + ip, 15, 3600], ["reg:all", 300, 3600]],
  login: (ip) => [["auth:" + ip, 60, 900]],
  recover: (ip) => [["auth:" + ip, 60, 900]],
  withdraw: (ip) => [["wd:" + ip, 20, 900]],
};
async function limited(rules: [string, number, number][]): Promise<boolean> {
  for (const [bucket, max, win] of rules) {
    const { data } = await db.rpc("rl_count", { p_bucket: bucket, p_window_s: win });
    if ((data ?? 0) >= max) return true;
  }
  for (const [bucket] of rules) await db.rpc("rl_add", { p_bucket: bucket });
  return false;
}

// Seuls ces messages métier sont renvoyés tels quels ; le reste reste générique
const SAFE = [/^code secret/i, /^consentement parental/i, /^code de parrainage inconnu/i];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: H });
  try {
    const b = await req.json();
    const r = routes[b.action];
    if (!r) return out({ error: "action inconnue" }, 400);
    const ip = await ipHash(req);
    const rules = LIMITS[b.action];
    if (rules && await limited(rules(ip))) {
      return out({ error: "trop de tentatives, réessayez dans quelques minutes" }, 429);
    }
    const [fn, args] = r(b, ip);
    const { data, error } = await db.rpc(fn, args);
    if (error) {
      const raw = error.message ?? "";
      let m: string;
      if (raw.includes("duplicate")) m = "numéro déjà inscrit";
      else if (SAFE.some((re) => re.test(raw))) m = raw;
      else if (raw.includes("violates check constraint")) m = "informations invalides, vérifiez le formulaire";
      else { console.error(fn, raw); m = "erreur temporaire, réessayez"; }
      return out({ error: m }, 400);
    }
    return out(data ?? { ok: true });
  } catch {
    return out({ error: "requête invalide" }, 400);
  }
});
