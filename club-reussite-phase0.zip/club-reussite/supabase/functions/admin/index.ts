import { createClient } from "npm:@supabase/supabase-js@2";

const KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(Deno.env.get("SUPABASE_URL")!, KEY);
const H = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Content-Type": "application/json",
};
const out = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: H });

const enc = new TextEncoder();
async function ipHash(req: Request): Promise<string> {
  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-real-ip") ??
    req.headers.get("x-forwarded-for")?.split(",").pop()?.trim() ?? "?";
  const k = await crypto.subtle.importKey("raw", enc.encode(KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const s = await crypto.subtle.sign("HMAC", k, enc.encode(ip));
  return [...new Uint8Array(s)].map((x) => x.toString(16).padStart(2, "0")).join("").slice(0, 32);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: H });
  try {
    const b = await req.json();
    // Verrou par connexion : 5 clés fausses = 15 minutes pour cette connexion seulement
    // (un tiers ne peut plus bloquer la console de l'administrateur)
    const bucket = "admfail:" + await ipHash(req);
    const { data: n } = await db.rpc("rl_count", { p_bucket: bucket, p_window_s: 900 });
    if ((n ?? 0) >= 5) return out({ error: "verrouillé 15 minutes" });
    const { data, error } = await db.rpc("admin_call", { p_key: String(b.key ?? ""), p_action: String(b.action ?? ""), p_args: b.args ?? {} });
    if (error) return out({ error: "erreur serveur" }, 500);
    if (data && data.error === "clé invalide") await db.rpc("rl_add", { p_bucket: bucket });
    return out(data);
  } catch {
    return out({ error: "requête invalide" }, 400);
  }
});
